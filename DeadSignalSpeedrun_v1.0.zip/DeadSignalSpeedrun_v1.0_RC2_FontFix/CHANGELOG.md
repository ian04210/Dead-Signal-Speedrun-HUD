# v1.0 RC2 — Font cache fix

- Refresh the native game font cache from the current title screen when the Speedrun card is created or reused, rather than only on first launch.
- Refuse to replace a cached font with an invalid FontObject, and clear stale FontMaterial references.
- No changes to timer calculations, run hooks, restart protection, image assets, HUD layout, or outline.

# Dead Signal Speedrun v1.0 RC1 — Release candidate

- Consolidates the user-tested UI Outline Patch, including restart-crash protections, native-style Speedrun card, gold stopwatch artwork, compact stacked RTA/IGT, and high-contrast timer text.
- Removes developer-only **F8 manual start** and **F9 manual finish** controls. Automatic start and GameEnd hooks remain unchanged.
- Replaces test-build instructions with public-facing installation and timing caveats.

**Not verified:** successful run ending fade; fresh UE4SS installation with this exact archive. The reported HUD font fallback on restart/death is not specifically changed in this release candidate and should be monitored.
