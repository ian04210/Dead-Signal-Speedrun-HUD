# Dead Signal Speedrun v1.0 RC2

**Release candidate — not yet approved for public leaderboard use.** This is a UE4SS Lua mod for Dead Signal (Windows, Unreal Engine 5.2). Development/testing used Dead Signal 2.0.0 and UE4SS 3.0.1 beta. Other versions are unverified.

## Features

- A fourth **SPEEDRUN** mode card with gold stopwatch artwork, game-native hover and cursor, and description. Selecting it launches the game's **Casual** difficulty.
- A compact upper-right HUD with **RTA above IGT**, game-style typography and a thin black outline for readability.
- Both clocks start automatically on **Begin Shift** (not upon picking Speedrun).
- **RTA** tracks elapsed real time during gameplay, pauses and loading, and updates continuously.
- **IGT** is an *estimated gameplay-time accumulator*. It excludes detected pauses/loads and unusually long update stalls. For this version, the visible IGT updates **only** when a pause/loading/finish checkpoint is detected; it is **not** a continuously updating game-owned timer.
- Clocks freeze when a recognized `GameEnd` callback occurs. We have confirmed a death can stop the timer, but precise successful ending-fade timing has **not** been verified.
- Restart-safety logic lets you return to the menu and start another run without restarting the game. This has been tested in development.

## Requirements

- Windows PC copy of Dead Signal. Developed for Dead Signal 2.0.0; other versions not checked.
- UE4SS v3.0.1 installed and working in `DeadSignal\Binaries\Win64`.
- No other copy of the DeadSignalSpeedrun mod or older MenuProbe active.

## Installation (test on a clean setup before public release)

1. Fully close Dead Signal.
2. Install UE4SS 3.0.1 into the game's `DeadSignal\Binaries\Win64` folder, using the standard UE4SS installation instructions. UE4SS itself is **not** included here.
3. Open `DeadSignal\Binaries\Win64\Mods`. If an old `DeadSignalSpeedrun` folder exists, remove it first; do not merge folders.
4. Extract the `DeadSignalSpeedrun` folder from this archive directly inside `Mods`, so the Lua file ends at `Mods\DeadSignalSpeedrun\scripts\main.lua` and the texture ends at `Mods\DeadSignalSpeedrun\assets\stopwatch_gold.png`.
5. In `Mods\mods.txt`, add or enable **`DeadSignalSpeedrun : 1`**. Disable `DeadSignalMenuProbe` if present, for example **`DeadSignalMenuProbe : 0`**. Avoid duplicate `DeadSignalSpeedrun` entries.
6. Launch the game, choose **New Game → Speedrun**, and click **Begin Shift**. Both timers should start automatically.

No manual timer-start or timer-stop hotkeys are included in RC1.

## Remaining release verification (2 checks)

- **Full successful Casual run:** have a runner record the ending and confirm the frozen RTA/IGT match the correct ending fade. A death stopping the timer does *not* validate a successful finish.
- **Clean installation:** someone who has not used the old dev builds should install this exact ZIP on a compatible UE4SS setup and verify launch, art, text, automatic start, pause checkpoints and repeat-run behavior.

## Timing and leaderboard caveats

- IGT uses a heuristic estimate rather than the game's official timer. Do not describe it as validated leaderboard IGT without reviewing its accuracy and the community's timing rules.
- The exact end-of-run trigger for successful completion has not yet been verified.
- This is an unofficial community-created modification, not an official Dead Signal feature.

## Troubleshooting / remove

- If the mod fails to load, check `Mods\mods.txt`, folder nesting, version compatibility and the UE4SS log under `DeadSignal\Binaries\Win64`.
- If it crashes, back up the log and any Unreal crash report; a UE4SS log alone may not contain the native crash stack.
- Uninstall by closing the game, deleting `Mods\DeadSignalSpeedrun`, and disabling its `mods.txt` entry.

**Author credit in the UI:** Made by ian04.

## RC2 font cache fix

On long runs ending in a return to the menu, RC1 could retain a reference to the first title screen's font asset, which later became unavailable during level travel. RC2 refreshes the font source from the current native title screen whenever the Speedrun button is inserted or reused. The RTA/IGT timing, start/end hooks, menu button, gold artwork, and 1px text outline are unchanged. This is a private test build until retested after an in-game restart.
